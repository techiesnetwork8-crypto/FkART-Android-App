# FKART.COM — Corrected Android APK Builder

Use the `FKART-APK-Project` folder as the Android project.

The previous workflow failed because the repository contained the project ZIP instead of the actual Android project files, and the workflow used Gradle 8.7 with Android Gradle Plugin 8.7.3. AGP 8.7 requires Gradle 8.9.

For GitHub Actions, the project files must be committed to the repository and the workflow must be at:
`.github/workflows/build-apk.yml`

After committing the project, open **Actions → Build FKART APK → Run workflow**. The generated debug APK is uploaded under **Artifacts → FKART-COM-debug-apk**.
