# FKART.COM Android APK Builder

This is a corrected Android WebView project for FKART.COM.

## Build
- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Java: 17
- Compile/target SDK: 35
- Package: com.fkart.app
- Website: https://fkart-com-ync3p8.v2.appdeploy.ai/

The GitHub Actions workflow builds a debug APK and uploads it as an artifact named `FKART-COM-debug-apk`.

## Important
The GitHub web interface does not automatically extract ZIP files. For GitHub Actions to run this workflow, the project files must exist in the repository (with `.github/workflows/build-apk.yml` in that exact folder), not only inside a ZIP attachment.
