# FKART.COM Android APK — GitHub Ready

This is a simple Android WebView app that opens the live FKART.COM website.

- App name: FKART.COM
- Package: com.fkart.app
- Minimum Android: 6.0 (API 23)
- Target Android: API 35
- Website: https://fkart-com-ync3p8.v2.appdeploy.ai/

## Phone build
1. Extract this ZIP on your phone.
2. In GitHub, open your repository and choose Add file → Upload files.
3. Upload the extracted files/folders, including `.github/workflows/build-apk.yml`.
4. Commit to the `main` branch.
5. Open Actions → Build FKART APK.
6. Tap Run workflow.
7. Wait for the workflow to finish with a green check.
8. Open the completed workflow run.
9. Under Artifacts, tap `FKART-APK` to download it.
10. Extract the downloaded artifact ZIP and install `app-debug.apk`.

Important: Do NOT upload this ZIP as the only repository file. GitHub does not automatically extract a ZIP for the workflow. Upload the extracted project contents so the `.github/workflows/build-apk.yml` file is visible in the repository.

The workflow builds a debug APK for testing. A Play Store release needs production signing.
