# FKART.COM — One-Click APK Builder

This project contains a GitHub Actions workflow that builds an installable FKART.COM Android APK.

## Build on an Android phone

1. Create a GitHub repository (for example `fkart-android`).
2. Upload the contents of this project, including `.github/workflows/build-apk.yml`.
3. Open **Actions** → **Build FKART APK**.
4. Tap **Run workflow**.
5. Wait for the green check.
6. Open the completed run and download the **FKART-COM-debug-apk** artifact.
7. Extract the artifact ZIP and install `app-debug.apk`.

App: FKART.COM
Package: com.fkart.app
Live website: https://fkart-com-ync3p8.v2.appdeploy.ai/

This workflow creates a debug APK for installation/testing. A production Play Store release should use a signed release APK/AAB.
