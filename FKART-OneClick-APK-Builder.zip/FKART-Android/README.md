# FKART.COM Android APK Project

This is a native Android wrapper for the live FKART.COM storefront.

## App details
- App name: FKART.COM
- Package: `com.fkart.app`
- Version: 1.0.0
- Minimum Android: 6.0 (API 23)
- Target Android: API 35
- Live website: https://fkart-com-ync3p8.v2.appdeploy.ai/

## Build an APK in Android Studio
1. Install the latest Android Studio.
2. Open this `FKART-Android` folder.
3. Let Gradle sync and install the required Android SDK.
4. Select **Build > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.
6. For a distributable APK, use **Build > Generate Signed Bundle / APK > APK** and create/use your signing key.

## Important
This project uses a WebView so FKART.COM remains connected to the live online store. Website updates can therefore appear in the app without rebuilding the APK.

The included icon is a vector FKART-style placeholder. Replace `app/src/main/res/drawable/ic_fkart.xml` with the final FKART logo asset if you want the exact supplied logo.

For a production Play Store/TWA release, use a verified owned domain such as `fkart.com` and configure Android Digital Asset Links plus release signing.
